# Tshedimoso — Frontend

Client chat interface and staff administration portal for Tshedimoso, Tebelopele Wellness
Centre's AI-enabled digital health and client engagement platform. Pairs with the
`tebelopele-backend` API.

## Stack

Plain HTML/CSS/JS with ES modules — no build step, no framework, no bundler. Runs by
opening `index.html` through any static file server, and deploys as-is to GitHub Pages,
Netlify, Vercel (static), or any static host.

## Structure

```
index.html            Shell page, loads js/app.js as a module
css/styles.css         Design tokens + all component styles
js/
  config.js            API_BASE_URL — point this at your deployed backend
  api.js                Fetch wrapper + auth/session handling
  ui.js                 Small helpers: toast, modal, DOM builder, formatting
  app.js                Hash router, public shell, role-gated portal shell
  pages/
    chat.js              Client-facing chat widget (POST /api/chat/message)
    login.js             Staff login (POST /api/auth/login)
    overview.js          Portal dashboard / KPIs
    appointments.js      Appointment list + cancel
    conversations.js     Escalation queue — claim / resolve
    referrals.js         Referral tracking — status, follow-up, outcome
    content.js           Content library with draft→review→approved→published→retired workflow
    knowledgeBase.js      AI knowledge base entries the assistant is grounded in
    users.js              Staff accounts and roles (admin/super_admin only)
    auditLogs.js          Audit log viewer (admin/super_admin only)
```

## Routes

| Route | Page | Access |
|---|---|---|
| `#/` | Client chat | Public |
| `#/login` | Staff sign-in | Public |
| `#/portal/overview` | Dashboard | Any signed-in staff |
| `#/portal/appointments` | Appointments | admin, super_admin, appointment_manager, staff |
| `#/portal/conversations` | Escalation queue | admin, super_admin, staff, clinical |
| `#/portal/referrals` | Referrals | admin, super_admin, referral_manager, staff |
| `#/portal/content` | Content library | admin, super_admin, content_manager |
| `#/portal/knowledge-base` | Knowledge base | admin, super_admin, content_manager |
| `#/portal/users` | Staff & access | admin, super_admin |
| `#/portal/audit-logs` | Audit log | admin, super_admin |

Role checks here are for navigation/UX only — the backend enforces the same roles on
every request, so a hidden nav item is not the security boundary.

## Setup

1. Run the backend (`tebelopele-backend`) — see its own README.
2. Point this frontend at it. Either:
   - Edit `js/config.js` directly, or
   - Set `window.TSHEDIMOSO_API_BASE_URL` before `app.js` loads, e.g. add to
     `index.html`: `<script>window.TSHEDIMOSO_API_BASE_URL = 'https://api.yoursite.com';</script>`
3. Serve the folder — any static server works:
   ```bash
   npx serve .
   # or
   python3 -m http.server 8080
   ```
4. Open `#/` for the client chat, or `#/login` to sign in as staff (seeded admin
   credentials are in the backend's `.env.example`).

## Deploying

Because this is plain static files, the simplest path is GitHub Pages:

```bash
git init
git add .
git commit -m "Tshedimoso frontend"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

Then enable Pages on the repo (Settings → Pages → deploy from `main`), and set
`window.TSHEDIMOSO_API_BASE_URL` in `index.html` to your deployed backend's URL before
pushing, since GitHub Pages serves static files only — it can't run the Node backend.

## What this does and doesn't cover

This implements the screens and API calls; it hasn't been through cross-browser or
accessibility testing, and there's no build/lint/test tooling wired up. Treat it as a
working starting point, not a finished, audited frontend — see the backend README's
"Notes for a production rollout" for what else a real launch needs.
