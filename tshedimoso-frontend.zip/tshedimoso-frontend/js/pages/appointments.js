import { api } from '../api.js';
import { el, formatDate, toast } from '../ui.js';

const STATUS_BADGE = {
  open: 'badge', booked: 'badge-ok', completed: 'badge-ok', cancelled: 'badge-danger',
};

export async function renderAppointments() {
  const root = el(`
    <div>
      <div class="portal-topbar">
        <div><h1>Appointments</h1><p class="muted">Bookings across all TWC locations.</p></div>
        <div class="toolbar">
          <select id="status-filter">
            <option value="">All statuses</option>
            <option value="open">Open</option>
            <option value="booked">Booked</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>Appointments</h3></div>
        <div id="table-wrap"></div>
      </div>
    </div>
  `);

  const wrap = root.querySelector('#table-wrap');
  const filter = root.querySelector('#status-filter');

  async function load() {
    wrap.innerHTML = '<div class="loading-row">Loading\u2026</div>';
    const params = filter.value ? { status: filter.value } : {};
    const list = await api.listAppointments(params);
    renderTable(wrap, list, load);
  }

  filter.addEventListener('change', load);
  await load();
  return root;
}

function renderTable(wrap, list, reload) {
  if (list.length === 0) {
    wrap.innerHTML = '<div class="empty-state">No appointments match this filter.</div>';
    return;
  }
  wrap.innerHTML = '';
  const table = el(`
    <table>
      <thead>
        <tr><th>When</th><th>Service</th><th>Location</th><th>Client</th><th>Status</th><th></th></tr>
      </thead>
      <tbody></tbody>
    </table>
  `);
  const tbody = table.querySelector('tbody');

  list.forEach((a) => {
    const row = el(`
      <tr>
        <td>${formatDate(a.startTime)}</td>
        <td>${a.service}</td>
        <td>${a.location}</td>
        <td>${a.client ? `${a.client.name || 'Unnamed'} · ${a.client.phone}` : '—'}</td>
        <td><span class="${STATUS_BADGE[a.status] || 'badge'}">${a.status}</span></td>
        <td></td>
      </tr>
    `);
    const actionsCell = row.lastElementChild;
    if (a.status === 'booked') {
      const cancelBtn = el('<button class="btn btn-danger btn-sm">Cancel</button>');
      cancelBtn.addEventListener('click', async () => {
        try {
          await api.updateAppointment(a.id, { status: 'cancelled' });
          toast('Appointment cancelled');
          reload();
        } catch (err) {
          toast(err.message, { error: true });
        }
      });
      actionsCell.appendChild(cancelBtn);
    }
    tbody.appendChild(row);
  });

  wrap.appendChild(table);
}
