import { api } from '../api.js';
import { el } from '../ui.js';

export function renderChat() {
  let sessionId = null;

  const root = el(`
    <div>
      <div class="chat-shell">
        <div class="chat-head">
          <div class="avatar"></div>
          <div>
            <b>Tshedimoso</b>
            <span>Tebelopele's digital assistant</span>
          </div>
        </div>
        <div class="chat-body" id="chat-body"></div>
        <form class="chat-form" id="chat-form">
          <input type="text" id="chat-input" placeholder="Type a message\u2026" autocomplete="off" />
          <button type="submit" aria-label="Send">&#10148;</button>
        </form>
      </div>
      <div class="staff-link">TWC staff? <a href="#/login">Sign in to the portal</a></div>
    </div>
  `);

  const body = root.querySelector('#chat-body');
  const form = root.querySelector('#chat-form');
  const input = root.querySelector('#chat-input');

  function addBubble(text, direction, escalated = false) {
    const bubble = el(`<div class="bubble ${direction}${escalated ? ' escalated' : ''}"></div>`);
    bubble.textContent = text;
    body.appendChild(bubble);
    body.scrollTop = body.scrollHeight;
  }

  function addTyping() {
    const typing = el('<div class="chat-typing" id="typing-indicator">Tshedimoso is typing\u2026</div>');
    body.appendChild(typing);
    body.scrollTop = body.scrollHeight;
    return typing;
  }

  addBubble(
    "Dumela! I'm Tshedimoso, Tebelopele's digital assistant. I can help you book an appointment, " +
      'share approved health information, arrange a referral, or connect you with staff. What do you need today?',
    'in'
  );

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message) return;
    input.value = '';
    addBubble(message, 'out');

    const typing = addTyping();
    try {
      const result = await api.sendChatMessage({ sessionId, channel: 'web', message });
      sessionId = result.sessionId;
      typing.remove();
      addBubble(result.reply, 'in', result.escalated);
    } catch (err) {
      typing.remove();
      addBubble(`Sorry — ${err.message}`, 'in');
    }
  });

  return root;
}
