import { api } from '../api.js';
import { el, formatDate, toast, openModal, closeModal } from '../ui.js';

const STATUS_BADGE = { open: 'badge-danger', in_progress: 'badge-warn', completed: 'badge-ok' };

export async function renderReferrals() {
  const root = el(`
    <div>
      <div class="portal-topbar">
        <div><h1>Referrals</h1><p class="muted">Tracked from request through to outcome.</p></div>
        <div class="toolbar">
          <select id="status-filter">
            <option value="">All statuses</option>
            <option value="open">Open</option>
            <option value="in_progress">In progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>Referrals</h3></div>
        <div id="table-wrap"></div>
      </div>
    </div>
  `);

  const wrap = root.querySelector('#table-wrap');
  const filter = root.querySelector('#status-filter');

  async function load() {
    wrap.innerHTML = '<div class="loading-row">Loading\u2026</div>';
    const params = filter.value ? { status: filter.value } : {};
    const list = await api.listReferrals(params);
    renderTable(wrap, list, load);
  }

  filter.addEventListener('change', load);
  await load();
  return root;
}

function renderTable(wrap, list, reload) {
  if (list.length === 0) {
    wrap.innerHTML = '<div class="empty-state">No referrals match this filter.</div>';
    return;
  }
  wrap.innerHTML = '';
  const table = el(`
    <table>
      <thead><tr><th>Raised</th><th>Client</th><th>Reason</th><th>Destination</th><th>Follow-up</th><th>Status</th><th></th></tr></thead>
      <tbody></tbody>
    </table>
  `);
  const tbody = table.querySelector('tbody');

  list.forEach((r) => {
    const row = el(`
      <tr>
        <td>${formatDate(r.createdAt)}</td>
        <td>${r.clientName || 'Unnamed'} · ${r.clientPhone}</td>
        <td style="max-width:220px;">${r.reason}</td>
        <td>${r.destination}</td>
        <td>${r.followUpDate ? formatDate(r.followUpDate) : '—'}</td>
        <td><span class="${STATUS_BADGE[r.status] || 'badge'}">${r.status.replace('_', ' ')}</span></td>
        <td></td>
      </tr>
    `);
    const editBtn = el('<button class="btn btn-ghost btn-sm">Update</button>');
    editBtn.addEventListener('click', () => openUpdateModal(r, reload));
    row.lastElementChild.appendChild(editBtn);
    tbody.appendChild(row);
  });

  wrap.appendChild(table);
}

function openUpdateModal(referral, reload) {
  const { backdrop, content } = openModal(`
    <h3>Update referral</h3>
    <form id="referral-form">
      <div class="field">
        <label for="status">Status</label>
        <select id="status">
          <option value="open" ${referral.status === 'open' ? 'selected' : ''}>Open</option>
          <option value="in_progress" ${referral.status === 'in_progress' ? 'selected' : ''}>In progress</option>
          <option value="completed" ${referral.status === 'completed' ? 'selected' : ''}>Completed</option>
        </select>
      </div>
      <div class="field">
        <label for="followUpDate">Follow-up date</label>
        <input type="date" id="followUpDate" value="${(referral.followUpDate || '').slice(0, 10)}" />
      </div>
      <div class="field">
        <label for="outcome">Outcome notes</label>
        <textarea id="outcome">${referral.outcome || ''}</textarea>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" id="cancel-btn">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  `);

  content.querySelector('#cancel-btn').addEventListener('click', () => closeModal(backdrop));
  content.querySelector('#referral-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const status = content.querySelector('#status').value;
    const followUpDate = content.querySelector('#followUpDate').value || null;
    const outcome = content.querySelector('#outcome').value;
    try {
      await api.updateReferral(referral.id, { status, followUpDate, outcome });
      toast('Referral updated');
      closeModal(backdrop);
      reload();
    } catch (err) {
      toast(err.message, { error: true });
    }
  });
}
