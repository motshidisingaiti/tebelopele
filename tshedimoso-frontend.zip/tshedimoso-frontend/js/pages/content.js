import { api } from '../api.js';
import { el, toast, openModal, closeModal, escapeHtml } from '../ui.js';

const STATE_BADGE = {
  draft: 'badge', in_review: 'badge-warn', approved: 'badge-warn', published: 'badge-ok', retired: 'badge-danger',
};
const NEXT_STATE = { draft: 'in_review', in_review: 'approved', approved: 'published', published: 'retired' };
const NEXT_LABEL = { draft: 'Send for review', in_review: 'Approve', approved: 'Publish', published: 'Retire' };

export async function renderContent() {
  const root = el(`
    <div>
      <div class="portal-topbar">
        <div><h1>Content library</h1><p class="muted">Approved health education used by the assistant.</p></div>
        <button class="btn btn-primary" id="new-btn">New item</button>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>All content</h3></div>
        <div id="table-wrap"></div>
      </div>
    </div>
  `);

  const wrap = root.querySelector('#table-wrap');

  async function load() {
    wrap.innerHTML = '<div class="loading-row">Loading\u2026</div>';
    // state omitted -> backend returns 'published' only for anonymous callers,
    // but as staff we ask for every state explicitly and merge.
    const states = ['draft', 'in_review', 'approved', 'published', 'retired'];
    const results = await Promise.all(states.map((s) => api.listContent({ state: s })));
    const items = results.flat().sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
    renderTable(wrap, items, load);
  }

  root.querySelector('#new-btn').addEventListener('click', () => openEditModal(null, load));
  await load();
  return root;
}

function renderTable(wrap, items, reload) {
  if (items.length === 0) {
    wrap.innerHTML = '<div class="empty-state">No content yet — add the first item.</div>';
    return;
  }
  wrap.innerHTML = '';
  const table = el(`
    <table>
      <thead><tr><th>Title</th><th>Category</th><th>State</th><th></th></tr></thead>
      <tbody></tbody>
    </table>
  `);
  const tbody = table.querySelector('tbody');

  items.forEach((item) => {
    const row = el(`
      <tr>
        <td>${escapeHtml(item.title)}</td>
        <td>${escapeHtml(item.category)}</td>
        <td><span class="${STATE_BADGE[item.state] || 'badge'}">${item.state.replace('_', ' ')}</span></td>
        <td></td>
      </tr>
    `);
    const actionsCell = row.lastElementChild;

    const editBtn = el('<button class="btn btn-ghost btn-sm">Edit</button>');
    editBtn.addEventListener('click', () => openEditModal(item, reload));
    actionsCell.appendChild(editBtn);

    const next = NEXT_STATE[item.state];
    if (next) {
      const advanceBtn = el(`<button class="btn btn-primary btn-sm" style="margin-left:6px;">${NEXT_LABEL[item.state]}</button>`);
      advanceBtn.addEventListener('click', async () => {
        try {
          await api.transitionContent(item.id, next);
          toast(`Moved to ${next.replace('_', ' ')}`);
          reload();
        } catch (err) {
          toast(err.message, { error: true });
        }
      });
      actionsCell.appendChild(advanceBtn);
    }
    tbody.appendChild(row);
  });

  wrap.appendChild(table);
}

function openEditModal(item, reload) {
  const isNew = !item;
  const { backdrop, content } = openModal(`
    <h3>${isNew ? 'New content item' : 'Edit content item'}</h3>
    <form id="content-form">
      <div class="field">
        <label for="title">Title</label>
        <input type="text" id="title" required value="${item ? escapeHtml(item.title) : ''}" />
      </div>
      <div class="field">
        <label for="category">Category</label>
        <input type="text" id="category" required value="${item ? escapeHtml(item.category) : ''}" />
      </div>
      <div class="field">
        <label for="summary">Summary</label>
        <input type="text" id="summary" value="${item ? escapeHtml(item.summary) : ''}" />
      </div>
      <div class="field">
        <label for="body">Body</label>
        <textarea id="body" required>${item ? escapeHtml(item.body) : ''}</textarea>
      </div>
      <div class="field">
        <label for="source">Source</label>
        <input type="text" id="source" placeholder="e.g. TWC Clinical Team" value="${item && item.source ? escapeHtml(item.source) : ''}" />
      </div>
      ${!isNew ? '<p class="field-hint">Editing creates a new version in the content history.</p>' : ''}
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" id="cancel-btn">Cancel</button>
        <button type="submit" class="btn btn-primary">${isNew ? 'Create' : 'Save changes'}</button>
      </div>
    </form>
  `);

  content.querySelector('#cancel-btn').addEventListener('click', () => closeModal(backdrop));
  content.querySelector('#content-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      title: content.querySelector('#title').value.trim(),
      category: content.querySelector('#category').value.trim(),
      summary: content.querySelector('#summary').value.trim(),
      body: content.querySelector('#body').value.trim(),
      source: content.querySelector('#source').value.trim() || null,
    };
    try {
      if (isNew) {
        await api.createContent(payload);
        toast('Content created as draft');
      } else {
        await api.updateContent(item.id, payload);
        toast('Content updated');
      }
      closeModal(backdrop);
      reload();
    } catch (err) {
      toast(err.message, { error: true });
    }
  });
}
